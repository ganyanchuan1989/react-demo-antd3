import React from "react";
import { DatePicker } from "antd";

export default function DateDemo() {
  return (
    <div>
      <DatePicker></DatePicker>
    </div>
  );
}
