import React from "react";
import TableGroup from "./TableGroup";
import PaginationDemo from "./PaginationDemo";
import ResizeTable from "./ResizeTable";

export default function index() {
  return (
    <div>
      {/* <PaginationDemo />
      <TableGroup></TableGroup> */}
      <ResizeTable></ResizeTable>
    </div>
  );
}
